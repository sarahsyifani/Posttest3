package posttest3;

public class SoloDuo extends Daftar{
    int jumlahArtis;

    public SoloDuo(String nama, String agensi, String judul, int urut, int jumlahArtis){
        super(nama, agensi, judul, urut);
        this.jumlahArtis = jumlahArtis;
    }

    public void setJumlahArtis(int jumlahArtis) {
        this.jumlahArtis = jumlahArtis;
    }

    public int getJumlahArtis() {
        return jumlahArtis;
    }
}
