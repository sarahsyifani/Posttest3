package posttest3;

public class Grup extends Daftar{
    int jumlahAnggota;

    public Grup(String nama, String agensi, String judul, int urut, int jumlahAnggota){
        super(nama, agensi, judul, urut);
        this.jumlahAnggota = jumlahAnggota;
    }

    public void setJumlahAnggota(int jumlahAnggota) {
        this.jumlahAnggota = jumlahAnggota;
    }

    public int getJumlahAnggota() {
        return jumlahAnggota;
    }
}
